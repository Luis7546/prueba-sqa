import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;


public class NavigationTest {

    private WebDriver driver;

    @BeforeEach
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\luisa\\IdeaProjects\\selenium-basic\\src\\test\\resources\\chromedriver.exe");
        driver = new ChromeDriver();

    }

    @Test
    public void navigateToOpensource() {
        driver.get("https://www.amazon.com/");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        System.out.println("Por favor, resuelve el CAPTCHA manualmente. Esperando 30 segundos...");
        try {
            Thread.sleep(15000); // Pausa de 30 segundos (30,000 ms)
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement BotonCaptcha = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@type='submit']")));
        BotonCaptcha.click();

        WebElement Continuar = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='a-button-input']")));
        Continuar.click();


        WebElement OfertaDeldia = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/-/es/gp/goldbox?ref_=nav_cs_gb']")));
        OfertaDeldia.click();

        WebElement Seleccionar1Producto = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='https://www.amazon.com/permanentes-exteriores-iluminaci%C3%B3n-Halloween-impermeable/dp/B0CGJ3NF5D?ref=dlx_deals_dg_dcl_B0CGJ3NF5D_dt_sl14_cd']")));
        Seleccionar1Producto.click();

        WebElement AgregarProducto1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='add-to-cart-button']")));
        AgregarProducto1.click();

        WebElement IrAlCarrito = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='/-/es/cart?ref_=sw_gtc']")));
        IrAlCarrito.click();

        WebElement EliminarProdCarrito = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='submit.delete.4fff4b87-16eb-42b4-a7a0-56b2cfcd3a02']")));
        EliminarProdCarrito.click();

    }
}









